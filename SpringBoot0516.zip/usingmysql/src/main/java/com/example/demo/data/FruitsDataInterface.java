package com.example.demo.data;

public interface FruitsDataInterface {
	public int getId();
	public void setId(int id);
	public String getName();
	public void setName(String name);
	public int getPrice();
	public void setPrice(int price);
	public int getStock();
	public void setStock(int stock);
}        
